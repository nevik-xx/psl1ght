vertex shader is precompiled. If you want modify and compile it uses:

make shader



